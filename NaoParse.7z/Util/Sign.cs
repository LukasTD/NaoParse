﻿namespace NaoParse.Util
{
	/// <summary>
	/// Alissa ops
	/// </summary>
	internal static class Sign
	{
		public const int Connect = 100;
		public const int Disconnect = 101;
		public const int Send = 0x10101011;
		public const int Recv = 0x10101012;
	}
}
